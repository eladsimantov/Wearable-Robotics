//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: predictGraspLD_types.h
//
// MATLAB Coder version            : 24.1
// C/C++ source code generated on  : 18-Aug-2025 16:58:49
//

#ifndef PREDICTGRASPLD_TYPES_H
#define PREDICTGRASPLD_TYPES_H

// Include Files
#include "rtwtypes.h"

#endif
//
// File trailer for predictGraspLD_types.h
//
// [EOF]
//
