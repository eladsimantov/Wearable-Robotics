//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: predictGraspLD_initialize.h
//
// MATLAB Coder version            : 24.1
// C/C++ source code generated on  : 18-Aug-2025 16:58:49
//

#ifndef PREDICTGRASPLD_INITIALIZE_H
#define PREDICTGRASPLD_INITIALIZE_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void predictGraspLD_initialize();

#endif
//
// File trailer for predictGraspLD_initialize.h
//
// [EOF]
//
