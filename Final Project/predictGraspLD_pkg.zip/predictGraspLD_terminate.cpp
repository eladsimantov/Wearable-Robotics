//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: predictGraspLD_terminate.cpp
//
// MATLAB Coder version            : 24.1
// C/C++ source code generated on  : 18-Aug-2025 16:58:49
//

// Include Files
#include "predictGraspLD_terminate.h"
#include "rt_nonfinite.h"

// Function Definitions
//
// Arguments    : void
// Return Type  : void
//
void predictGraspLD_terminate()
{
}

//
// File trailer for predictGraspLD_terminate.cpp
//
// [EOF]
//
