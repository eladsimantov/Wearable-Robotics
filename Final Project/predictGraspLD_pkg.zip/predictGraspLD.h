//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: predictGraspLD.h
//
// MATLAB Coder version            : 24.1
// C/C++ source code generated on  : 18-Aug-2025 16:58:49
//

#ifndef PREDICTGRASPLD_H
#define PREDICTGRASPLD_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern double predictGraspLD(const double inputData[18]);

#endif
//
// File trailer for predictGraspLD.h
//
// [EOF]
//
