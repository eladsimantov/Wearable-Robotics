//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: CompactClassificationDiscriminant.h
//
// MATLAB Coder version            : 24.1
// C/C++ source code generated on  : 18-Aug-2025 16:58:49
//

#ifndef COMPACTCLASSIFICATIONDISCRIMINANT_H
#define COMPACTCLASSIFICATIONDISCRIMINANT_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Type Definitions
namespace coder {
namespace classreg {
namespace learning {
namespace coderutils {
enum class Transform : int
{
  Logit = 0, // Default value
  Doublelogit,
  Invlogit,
  Ismax,
  Sign,
  Symmetric,
  Symmetricismax,
  Symmetriclogit,
  Identity
};

}
namespace classif {
class CompactClassificationDiscriminant {
public:
  static void mahalLinear(const double X[18], double mah[13]);
  int ClassNamesLength[13];
  coderutils::Transform ScoreTransform;
  double Prior[13];
  bool ClassLogicalIndices[13];
  double Cost[169];
  double Gamma;
  double Delta;

protected:
  double LogDetSigma;
};

} // namespace classif
} // namespace learning
} // namespace classreg
} // namespace coder

#endif
//
// File trailer for CompactClassificationDiscriminant.h
//
// [EOF]
//
