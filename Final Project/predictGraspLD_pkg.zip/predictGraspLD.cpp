//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: predictGraspLD.cpp
//
// MATLAB Coder version            : 24.1
// C/C++ source code generated on  : 18-Aug-2025 16:58:49
//

// Include Files
#include "predictGraspLD.h"
#include "CompactClassificationDiscriminant.h"
#include "rt_nonfinite.h"
#include <algorithm>
#include <cmath>
#include <cstring>

// Function Definitions
//
// Arguments    : const double inputData[18]
// Return Type  : double
//
double predictGraspLD(const double inputData[18])
{
  static const double S[18]{
      2.9501391352114936,   1.7477383894663192,  1.4591124871053478,
      1.332057068534789,    0.82708591277075871, 0.72168971267260562,
      0.6654506984557591,   0.50904518913890362, 0.41142016193458691,
      0.3663767452805976,   0.21199183067333185, 0.17580249345785354,
      0.15728038609371803,  0.11932571984444719, 0.10516493268714482,
      0.034997900908684161, 0.02755882161119335, 0.021914874412235861};
  static const double dv[18]{
      7.1776489127706338,   10.646883428127873, 9.367835111365947,
      0.086899614070418088, 36.834426744160126, 0.4671120825738006,
      15.997110810545662,   18.719773761282234, 13.182909247526595,
      0.066881440865849393, 50.644594361028879, 0.37170539293503296,
      20.318369817997628,   24.444610809960253, 16.81041519429343,
      0.077871470945673121, 64.28975532981832,  0.36869867305862219};
  static const double dv1[13]{
      0.74043673532600274,  0.023695214495895928, 0.023230602446956791,
      0.024159826544835061, 0.023772649837385782, 0.0246244385937742,
      0.024159826544835061, 0.024159826544835061, 0.024159826544835061,
      0.024082391203345207, 0.024159826544835061, 0.0096794176862319958,
      0.0096794176862319958};
  static const double dv2[13]{0.0, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5,
                              4.0, 4.5, 5.0, 5.5, 6.0, 6.5};
  coder::classreg::learning::classif::CompactClassificationDiscriminant model;
  double logP[13];
  double mah[13];
  double d;
  double logDetSigma;
  int i;
  int idx;
  int ii;
  signed char b_I[169];
  signed char iv[169];
  //  Load the model
  logDetSigma = 0.0;
  for (ii = 0; ii < 18; ii++) {
    logDetSigma += 2.0 * std::log(dv[ii]);
    logDetSigma += 2.0 * std::log(S[ii]);
  }
  std::copy(&dv1[0], &dv1[13], &model.Prior[0]);
  std::memset(&b_I[0], 0, 169U * sizeof(signed char));
  for (ii = 0; ii < 13; ii++) {
    b_I[ii + 13 * ii] = 1;
  }
  //  Make predictions
  coder::classreg::learning::classif::CompactClassificationDiscriminant::
      mahalLinear(inputData, mah);
  for (ii = 0; ii < 13; ii++) {
    logP[ii] = (std::log(model.Prior[ii]) - logDetSigma / 2.0) - mah[ii] / 2.0;
  }
  logDetSigma = logP[0];
  for (ii = 0; ii < 13; ii++) {
    d = logP[ii];
    if (logDetSigma < d) {
      logDetSigma = d;
    }
  }
  if (std::isinf(logDetSigma) || (logDetSigma == -1.7976931348623157E+308)) {
    for (i = 0; i < 13; i++) {
      logP[i] = rtNaN;
    }
  } else {
    for (ii = 0; ii < 13; ii++) {
      logP[ii] = std::exp(logP[ii] - logDetSigma);
    }
    logDetSigma = logP[0];
    for (ii = 0; ii < 12; ii++) {
      logDetSigma += logP[ii + 1];
    }
    for (i = 0; i < 13; i++) {
      logP[i] /= logDetSigma;
    }
  }
  for (i = 0; i < 169; i++) {
    iv[i] = static_cast<signed char>(1 - b_I[i]);
  }
  for (i = 0; i < 13; i++) {
    d = 0.0;
    for (ii = 0; ii < 13; ii++) {
      d += logP[ii] * static_cast<double>(iv[ii + 13 * i]);
    }
    mah[i] = d;
  }
  if (!std::isnan(mah[0])) {
    idx = 1;
  } else {
    bool exitg1;
    idx = 0;
    ii = 2;
    exitg1 = false;
    while ((!exitg1) && (ii < 14)) {
      if (!std::isnan(mah[ii - 1])) {
        idx = ii;
        exitg1 = true;
      } else {
        ii++;
      }
    }
  }
  if (idx == 0) {
    idx = 1;
  } else {
    logDetSigma = mah[idx - 1];
    i = idx + 1;
    for (ii = i; ii < 14; ii++) {
      d = mah[ii - 1];
      if (logDetSigma > d) {
        logDetSigma = d;
        idx = ii;
      }
    }
  }
  return dv2[idx - 1];
}

//
// File trailer for predictGraspLD.cpp
//
// [EOF]
//
