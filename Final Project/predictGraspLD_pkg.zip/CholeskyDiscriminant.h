//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: CholeskyDiscriminant.h
//
// MATLAB Coder version            : 24.1
// C/C++ source code generated on  : 18-Aug-2025 16:58:49
//

#ifndef CHOLESKYDISCRIMINANT_H
#define CHOLESKYDISCRIMINANT_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
namespace classreg {
namespace learning {
namespace coder {
namespace discrutils {
void CholeskyDiscriminant(const double X[18], const double invR[324],
                          double mah[13]);

}
} // namespace coder
} // namespace learning
} // namespace classreg
} // namespace coder

#endif
//
// File trailer for CholeskyDiscriminant.h
//
// [EOF]
//
